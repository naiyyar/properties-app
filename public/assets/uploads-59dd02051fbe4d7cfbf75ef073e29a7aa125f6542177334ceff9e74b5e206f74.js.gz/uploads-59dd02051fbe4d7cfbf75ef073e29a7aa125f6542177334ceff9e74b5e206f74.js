(function() {
  $(document).on('click', '.delete_image', function(e) {
    return $(this).parent().hide(500);
  });

}).call(this);
